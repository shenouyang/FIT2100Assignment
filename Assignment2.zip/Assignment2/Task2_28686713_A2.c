/*
 * Name: shenOuyang
 * Strudent ID: 28686713
 * Description: This file implements a scheduler strategy of Round RObin
 * Start date: 18/10/2020
 * Last Modify: 26/10/2020
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>

/* Special enumerated data type for process state */
typedef enum {
    READY = 0,
    RUNNING = 1,
    EXIT = 2,
    ENTER = 3
} process_state_t;

typedef struct {
    char process_name[11]; // a string that identifies the process
    /* Times measured in seconds... */
    int entryTime;     // time process entered system
    int serviceTime;   // the total CPU time required by the process
    int remainingTime; // remaining service time until completion.
    int deadLine;      // Define Deadline

    int waitTime;       // The total wait time of each process
    int turnaroundTime; // The turnaround time of each process
    int ddlMet;         

    process_state_t state; // current process state (e.g. READY)
} pcb_t;


int count = 0;
int time = 0;
pcb_t *element = NULL;

//Determine whether all processes have run to completion
// Flase : process still running
// ture: all process in EXIT state.
bool all_exit()
{
    for (int i = 0; i < count; i++) {
        if (element[i].state != EXIT) {
            return false;
        }
    }
    return true;
}
//Find the earliest entryTime process and state is READY
int find_earliest()
{
    int tmp = time+1;
    int res = -1;
    for (int i = 0; i < count; i++) {
        if (element[i].state == READY && element[i].entryTime < tmp) {
            res = i;
            tmp = element[i].entryTime;
        }
    }
    //if cant found process which state is ready then retrun -1
    return res;
}
/* The Round Robin function
 * In this function, the program will simulate the execution of the Round Robin algorithm
 */
void RR()
{
    int iter = count-1;
    int qutuanm = 2;
    for(time = 0; !all_exit(); time++) {
        for (int i = 0; i < count; i++) {
            if (element[i].entryTime == time && element[i].state == ENTER) {
                printf("Time %d: %s has entered the system.\n", time, element[i].process_name);
                element[i].state = READY;
            }
        }
        if(element[iter].state == RUNNING) {
            if(element[iter].remainingTime == 1) {
                element[iter].state = EXIT;
                element[iter].waitTime = time - element[iter].serviceTime - element[iter].entryTime;
                element[iter].turnaroundTime = time - element[iter].entryTime;
                element[iter].ddlMet = (element[iter].turnaroundTime <= element[iter].deadLine) ? 1 : 0;
                printf("Time %d: %s has finished execution.\n", time, element[iter].process_name);
            } 
            //
            else {
                element[iter].remainingTime--;
                qutuanm--;
                //Consider if the next second the qutuanm become to 0, if so then found the next READY state process.
                if(qutuanm == 0) {
                    element[iter].state = READY;
                } else {
                    continue;
                }
            }
        }
        if(all_exit()){
            break;
        }
        //Found the next process which state is ready
        iter = (iter+1) % count; 
        while(element[iter].state != READY) {
            iter = (iter+1) % count;
        }
        printf("Time %d: %s is in the running state.\n", time, element[iter].process_name);
        element[iter].state = RUNNING;
        qutuanm = 2;
        sleep(1);
        continue;
    }
}

int main(int argc, char *argv[])
{
    // open file for getting data
    char *filename = "process-data.txt";
    if (argc > 1) {
        filename = argv[1];
    }
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        write(1, "invalid argument: no target file\n", 33);
        exit(1);
    }

    char process_name[11];
    int arrival_time;
    int service_time;
    int remaining_time;
    while (fscanf(file, "%s %d %d %d\n", process_name, &arrival_time, &service_time, &remaining_time) > 0) {
        count++; // get the count of element in data file
    }

    fseek(file, 0, SEEK_SET);

    // read in all element in txt.file and print it out
    element = (pcb_t *)malloc(count * sizeof(pcb_t));
    for (int i = 0; i < count; i++) {
        fscanf(file, "%s %d %d %d\n", element[i].process_name, &element[i].entryTime, &element[i].serviceTime, &element[i].deadLine);
        element[i].remainingTime = element[i].serviceTime;
        element[i].state = ENTER;
    }
    //implement Round Robin function.
    RR();
    // write data in target file.
    FILE *outfile = fopen("scheduler-result.txt", "w");
    for (int i = 0; i < count; i++) {
        fprintf(outfile, "%s %d %d %d\n", element[i].process_name, element[i].waitTime, element[i].turnaroundTime, element[i].ddlMet);
        fprintf(outfile,"%d second of waiting time\n",element[i].waitTime);
        fprintf(outfile,"%d second of turnaround time\n",element[i].turnaroundTime);
        fprintf(outfile,"%d times met the deadline\n",element[i].ddlMet);
    }
    fclose(outfile);
    fclose(file);
    return 0;
}
